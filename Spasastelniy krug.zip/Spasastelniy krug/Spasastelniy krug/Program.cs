﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spasastelniy_krug
{

    internal class Program
    {
        // Роль: Разработчик (Backend)
        // Промпт для AI: "Напиши метод на C# для чтения всех строк из файла, если файл не найден или пуст - вернуть null"
        static List<string> ReadFileLinesOrNull(string filePath)
        {
            if (!File.Exists(filePath))
                return null;

            var lines = File.ReadAllLines(filePath);
            if (lines.Length == 0)
                return null;

            return lines.Where(l => !string.IsNullOrWhiteSpace(l)).ToList();
        }

        // Роль: Разработчик (Backend)
        // Промпт: "Метод, который возвращает список студентов: из файла или резервный, с выводом предупреждения"
        static List<string> GetStudentsList()
        {
            var students = ReadFileLinesOrNull("students.txt");
            if (students == null)
            {
                Console.WriteLine("[Предупреждение] Файл students.txt не найден или пуст. Используются студенты по умолчанию.");
                return new List<string> { "Иванов И.И.", "Петров П.П.", "Сидоров С.С.", "Кузнецов А.А.", "Смирнова Е.В." };
            }
            return students;
        }

        // Роль: Разработчик (Backend)
        static List<string> GetReasonsList()
        {
            var reasons = ReadFileLinesOrNull("reasons.txt");
            if (reasons == null)
            {
                Console.WriteLine("[Предупреждение] Файл reasons.txt не найден или пуст. Используются причины по умолчанию.");
                return new List<string> { "Проспал", "Забыл номер аудитории", "Помогал бабушке перейти дорогу", "Участвовал в хакатоне" };
            }
            return reasons;
        }

        // Роль: Дизайнер (Интерфейс и ввод-вывод)
        // Промпт: "Напиши метод, который запрашивает у пользователя число, обрабатывает ошибки и отрицательные значения"
        static int GetUserInput()
        {
            Console.Write("Сколько записок сгенерировать? ");
            string input = Console.ReadLine();

            if (!int.TryParse(input, out int count))
            {
                Console.WriteLine("Ошибка ввода. Установлено значение по умолчанию: 5");
                return 5;
            }

            if (count < 0)
            {
                Console.WriteLine("Количество не может быть отрицательным. Установлено: 1");
                return 1;
            }

            return count;
        }

        // Роль: Дизайнер (Интерфейс и ввод-вывод)
        // Промпт: "Метод для генерации текста объяснительной записки с подстановкой студента, причины и текущей даты"
        static string GenerateExplanatoryText(string studentFullName, string reason)
        {
            string date = DateTime.Now.ToString("dd.MM.yyyy");
            return $@"Заведующему отделением (очного обучения)
От студента: {studentFullName}
Группа: ИС-51

---

ОБЪЯСНИТЕЛЬНАЯ ЗАПИСКА
Я, {studentFullName}, отсутствовал(а) на занятиях по уважительной причине:
""{reason}"".
Обязуюсь изучить пропущенный материал самостоятельно и впредь посещать все пары по дисциплине ""Управление проектами"".
Прошу не оценивать меня строго, больше такого не повторится
Дата: {date}
Подпись: ______";

        }

        // Роль: Дизайнер (Именование файлов)
        // Промпт: "Метод, который из строки 'Иванов И.И.' выделяет фамилию и инициалы без точек"
        static (string lastName, string initials) ParseStudentName(string fullName)
        {
            var parts = fullName.Split(' ');
            string lastName = parts[0];
            string initials = parts.Length > 1 ? parts[1].Replace(".", "") : "X";
            return (lastName, initials);
        }

        // Роль: Разработчик (Backend) - обработка прав на папку
        static void EnsureDirectoryExists(string path)
        {
            try
            {
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при создании папки: {ex.Message}");
                Environment.Exit(1);
            }
        }

        static void Main(string[] args)
        {
            Console.WriteLine("=== Генератор объяснительных для деканата (Спасательный круг) ===");

            // 1. Получаем списки
            var students = GetStudentsList();
            var reasons = GetReasonsList();

            // 2. Запрос количества
            int count = GetUserInput();

            // 3. Создаём папку
            string folderPath = "ExplanatoryNotes";
            EnsureDirectoryExists(folderPath);

            // 4. Генерация записок
            Random rand = new Random();
            int generated = 0;

            for (int i = 1; i <= count; i++)
            {
                // Выбираем случайного студента и случайную причину
                string student = students[rand.Next(students.Count)];
                string reason = reasons[rand.Next(reasons.Count)];

                // Разбираем фамилию и инициалы для имени файла
                var (lastName, initials) = ParseStudentName(student);
                string fileName = $"{i}_{lastName}_{initials}.txt";
                string fullPath = Path.Combine(folderPath, fileName);

                // Генерируем текст записки
                string content = GenerateExplanatoryText(student, reason);

                try
                {
                    File.WriteAllText(fullPath, content);
                    Console.WriteLine($"Создан: {fileName}");
                    generated++;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка записи {fileName}: {ex.Message}");
                }
            }

            Console.WriteLine($"\nГотово! Сгенерировано {generated} из {count} записок в папке '{folderPath}'");
            Console.WriteLine("Нажмите любую клавишу для выхода...");
            Console.ReadKey();
        }
    }
}


